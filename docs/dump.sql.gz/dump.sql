-- MySQL dump 10.17  Distrib 10.3.12-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: Absence
-- ------------------------------------------------------
-- Server version	10.3.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrators`
--

DROP TABLE IF EXISTS `administrators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrators` (
  `userID` int(11) unsigned zerofill NOT NULL,
  `accessLevel` varchar(45) DEFAULT 'moderator',
  PRIMARY KEY (`userID`),
  CONSTRAINT `fk_administrators_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='users with administrative privilegies, this table interaction must be analized';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrators`
--

LOCK TABLES `administrators` WRITE;
/*!40000 ALTER TABLE `administrators` DISABLE KEYS */;
INSERT INTO `administrators` VALUES (00000000155,'infinito');
/*!40000 ALTER TABLE `administrators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `categoryID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `desc` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (00000000001,'Trabajos del hogar','Plomeria'),(00000000002,'Chau','Hola'),(00000000003,'asd','Compania');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `userID` int(11) unsigned zerofill NOT NULL,
  `providerType` varchar(45) DEFAULT NULL,
  `prestigeID` int(11) NOT NULL,
  `birthDate` varchar(45) DEFAULT NULL,
  `fullName` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `postalCode` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userID`),
  CONSTRAINT `fk_providers_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='users who provide at least one service';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (00000000153,NULL,0,'1996-01-09','Tomas Ignacio Bargut Tabbaj','Darien 2031','4851556','2000'),(00000000154,NULL,0,'1996-02-05','Tomas','Darien 2031','4851556','2000'),(00000000156,NULL,0,'1986-01-23','Tomas Ignacio Bargut Tabbaj','Darien 2031','4851556','2000');
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `reportID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `sentDate` datetime DEFAULT NULL,
  `answerDate` datetime DEFAULT NULL,
  `statusID` int(11) DEFAULT NULL,
  `administratedBy` int(10) unsigned zerofill DEFAULT NULL,
  `reportType` int(11) DEFAULT NULL,
  `requestID` int(11) unsigned zerofill NOT NULL,
  PRIMARY KEY (`reportID`),
  KEY `admin_fk_idx` (`administratedBy`),
  KEY `fk_report_request` (`requestID`),
  CONSTRAINT `fk_admin` FOREIGN KEY (`administratedBy`) REFERENCES `administrators` (`userID`) ON UPDATE CASCADE,
  CONSTRAINT `fk_report_request` FOREIGN KEY (`requestID`) REFERENCES `requests` (`requestID`)
) ENGINE=InnoDB AUTO_INCREMENT=84509177 DEFAULT CHARSET=utf8 COMMENT='reports made by users who requested services, noticed bugs, or behavioral infractions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requests` (
  `requestID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `requesting_userID` int(10) unsigned zerofill NOT NULL,
  `serviceID` int(11) unsigned zerofill NOT NULL,
  `requestDate` datetime NOT NULL,
  `responseDate` datetime DEFAULT NULL,
  `request_statusID` varchar(10) NOT NULL DEFAULT 'solicitado',
  PRIMARY KEY (`requestID`),
  KEY `requesting_user_idx` (`requesting_userID`),
  KEY `provision_fk_idx` (`serviceID`),
  CONSTRAINT `fk_requests_1` FOREIGN KEY (`requesting_userID`) REFERENCES `users` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='represent requests of services provided by provider users (provisions) made by users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests`
--

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
INSERT INTO `requests` VALUES (00000000001,0000000157,00000000037,'2019-02-24 00:00:00',NULL,'CREADO');
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `reviewID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `pointsGiven` int(11) DEFAULT NULL,
  `picture` blob DEFAULT NULL,
  `reviewDate` varchar(45) DEFAULT NULL,
  `requestID` int(11) unsigned zerofill NOT NULL,
  PRIMARY KEY (`reviewID`),
  KEY `fk_review_request` (`requestID`),
  CONSTRAINT `fk_review_request` FOREIGN KEY (`requestID`) REFERENCES `requests` (`requestID`)
) ENGINE=InnoDB AUTO_INCREMENT=88213373 DEFAULT CHARSET=utf8 COMMENT='reviews made to provisions requested by users to providers';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `serviceID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `userID` int(11) unsigned zerofill DEFAULT NULL,
  PRIMARY KEY (`serviceID`),
  KEY `fk_service_user` (`userID`),
  CONSTRAINT `fk_service_user` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (00000000026,'Hola','Chau',00000000153),(00000000027,'Chau ','Hola',00000000153),(00000000028,'Adios','Bebe',00000000153),(00000000029,'Plomeria a domicilio','plomo',00000000153),(00000000033,'Mama','Tengo miedo',00000000153),(00000000037,'Pepito','Pollo frito',00000000153);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services_categories`
--

DROP TABLE IF EXISTS `services_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services_categories` (
  `serviceID` int(11) unsigned zerofill NOT NULL,
  `categoryID` int(11) unsigned zerofill NOT NULL,
  PRIMARY KEY (`serviceID`,`categoryID`),
  KEY `fk_services_categories_1_idx` (`categoryID`),
  CONSTRAINT `fk_services_categories_1` FOREIGN KEY (`categoryID`) REFERENCES `categories` (`categoryID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_services_categories_2` FOREIGN KEY (`serviceID`) REFERENCES `services` (`serviceID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services_categories`
--

LOCK TABLES `services_categories` WRITE;
/*!40000 ALTER TABLE `services_categories` DISABLE KEYS */;
INSERT INTO `services_categories` VALUES (00000000037,00000000001),(00000000037,00000000002),(00000000037,00000000003);
/*!40000 ALTER TABLE `services_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(45) NOT NULL,
  `lastLogin` varchar(45) DEFAULT NULL,
  `accountStatus` varchar(45) DEFAULT NULL,
  `salt` varchar(255) DEFAULT '',
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (00000000153,'teddie96','theend1969','tomasbarguttabbaj@gmail.com',NULL,NULL,''),(00000000154,'thomir1996','theend1969','tomasbargutt@gmail.com',NULL,NULL,''),(00000000155,'teddie1996','theend1969','tom_newels@hotmail.com',NULL,NULL,''),(00000000156,'morgana78','theend1969','morgana@gmail.com',NULL,NULL,''),(00000000157,'morgana96','theend1969','tomi@gmail.com',NULL,NULL,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-24 20:51:32
